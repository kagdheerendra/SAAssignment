import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthKeyClockGuard } from './routeguards/auth.route';

const routes: Routes = [
  {
    path: 'public',
    loadChildren: () => import('./public/public.module').then(m => m.PublicModule)
  },
  {
    path: 'protected',
    canActivate: [AuthKeyClockGuard],
    loadChildren: () => import('./protected/protected.module').then(m => m.ProtectedModule)
  },
  {
    path: '',
    redirectTo: 'protected',
    pathMatch: 'full'
  },  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
