import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProtectedRoutingModule } from './protected-routing.module';
import { HomeComponent } from './component/home/home.component';
import {MatSidenavModule} from '@angular/material/sidenav'
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatListModule} from '@angular/material/list';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {MatDialogModule} from '@angular/material/dialog';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatTableModule} from '@angular/material/table'
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { AddProductComponent } from './component/dashboard/component/add-product/add-product.component';
import { EditProductComponent } from './component/dashboard/component/edit-product/edit-product.component';
import { TreeviewComponent } from './component/treeview/treeview.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatTreeModule} from '@angular/material/tree';
import {MatMenuModule} from '@angular/material/menu';
import { GroupMemberDialogComponent } from './component/treeview/group-member-dialog/group-member-dialog.component';
import { D3viewComponent } from './component/treeview/d3view/d3view.component';

@NgModule({
  declarations: [
    HomeComponent,
    DashboardComponent,
    AddProductComponent,
    EditProductComponent,
    TreeviewComponent,
    GroupMemberDialogComponent,
    D3viewComponent
  ],
  imports: [
    CommonModule,
    ProtectedRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatIconModule,  
    MatButtonModule,
    MatCardModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    MatDialogModule,
    MatGridListModule,
    MatTreeModule,
    MatTabsModule,
    MatTableModule,
    MatMenuModule
  ]
})
export class ProtectedModule { }
