import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProtectedService {

  constructor(private http : HttpClient) { }

  getAllProduct() : Observable<any>{
    return this.http.get("http://localhost:8080/product/getAllProduct",{ observe: 'response',withCredentials: true });
  }

  // Add product in the system
  addProduct(product: any): Observable<any> {
    const formData: FormData = new FormData();
    formData.append("description", product.description);
    formData.append("price", product.price);
    formData.append("productname", product.productName);
    formData.append("quantity", product.quantity);
    formData.append("file", product.productimage);
    return this.http.post<any>("http://localhost:8080/product/addProduct", formData);

  }

  deleteProduct(id : number) : Observable<any>{
    return this.http.delete("http://localhost:8080/product/deleteProduct/"+id,{ observe: 'response',withCredentials: true });
  }

  // Add product in the system
  udpateProduct(product: any): Observable<any> {
    const formData: FormData = new FormData();
    formData.append("productid", product.productid);
    formData.append("description", product.description);
    formData.append("price", product.price);
    formData.append("productname", product.productName);
    formData.append("quantity", product.quantity);
    formData.append("file", product.productimage);
    return this.http.put<any>("http://localhost:8080/product/updateProduct", formData);

  }

  saveDepartment(obj: any): Observable<any> {
    //let json = JSON.stringify(obj);  
    return this.http.post<any>("http://localhost:8080/department/add", obj);
  }

  getAllDepartment() : Observable<any>{
    return this.http.get("http://localhost:8080/department/getAllDepartment",{ observe: 'response',withCredentials: true });
  }

  deleteDepartment(id : number) : Observable<any>{
    return this.http.delete("http://localhost:8080/department/delete/"+id,{ observe: 'response',withCredentials: true });
  }
}
