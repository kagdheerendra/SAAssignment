import { AfterViewInit, Component } from '@angular/core';
import { ProtectedService } from '../../protected.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AddProductComponent } from './component/add-product/add-product.component';
import { EditProductComponent } from './component/edit-product/edit-product.component';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent implements AfterViewInit{
  items : any[] = [{
    title : "Shiba Inu",
    subtitle : "Dog Breed",
    image : "https://material.angular.io/assets/img/examples/shiba2.jpg",
    content : `The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog from Japan.
    A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was originally
    bred for hunting.`
  },{
    title : "Shiba Inu",
    subtitle : "Dog Breed",
    image : "https://material.angular.io/assets/img/examples/shiba2.jpg",
    content : `The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog from Japan.
    A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was originally
    bred for hunting.`
  },{
    title : "Shiba Inu",
    subtitle : "Dog Breed",
    image : "https://material.angular.io/assets/img/examples/shiba2.jpg",
    content : `The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog from Japan.
    A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was originally
    bred for hunting.`
  },{
    title : "Shiba Inu",
    subtitle : "Dog Breed",
    image : "https://material.angular.io/assets/img/examples/shiba2.jpg",
    content : `The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog from Japan.
    A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was originally
    bred for hunting.`
  },{
    title : "Shiba Inu",
    subtitle : "Dog Breed",
    image : "https://material.angular.io/assets/img/examples/shiba2.jpg",
    content : `The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog from Japan.
    A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was originally
    bred for hunting.`
  }]
  currentUrl: any;
  keycloakRoles!:any;
  isUser!:boolean;
  constructor(private pservice: ProtectedService, public dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,){
    this.currentUrl = this.router.url;
    this.getAllProduct();
    this.keycloakRoles = window.sessionStorage.getItem('keycloakRoles');
    this.keycloakRoles = JSON.parse(this.keycloakRoles);
    this.isUser = this.keycloakRoles.includes('USER')
  }

  ngAfterViewInit(): void {
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    const dialogRef = this.dialog.open(AddProductComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
      data => {
        setTimeout(()=>{
          //if (data === "save") {
            this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
              this.router.navigate([this.currentUrl]);
            });
          //}
        },1000);
      }
    );
  }

  getAllProduct(){
    this.pservice.getAllProduct().subscribe(res=>{
      console.log(res);
      this.items = res['body'];
    })
  }

  deleteProduct(id : number){
    this.pservice.deleteProduct(id).subscribe(res => {
      if(res.status == 200){
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
          this.router.navigate([this.currentUrl]);
        });
      }
    });
  }

  updateProduct(product: any){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'data' : product
    }
    const dialogRef = this.dialog.open(EditProductComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
      data => {
        setTimeout(()=>{
          console.log(data);
          //if(data == "save"){
            this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
                this.router.navigate([this.currentUrl]);
            });
          //}
        },1000);

      }
  ); 
  }
}
