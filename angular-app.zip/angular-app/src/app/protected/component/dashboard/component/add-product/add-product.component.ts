import { Component, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ProtectedService } from '../../../../protected.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.scss'
})
export class AddProductComponent {

  private fileToUpload!: File;
  imageUrl: string = "/assets/img/noimage.png";

  productForm = new FormGroup({
    productName: new FormControl("", [Validators.required,  Validators.maxLength(50)]),
    description: new FormControl("", [Validators.required,  Validators.maxLength(250)]),
    quantity: new FormControl(null, [Validators.required, Validators.pattern("^-?[0-9][^\.]*$")]),
    price: new FormControl(null, [Validators.required])
  })

  constructor(private pService: ProtectedService,
    private dialogRef: MatDialogRef<AddProductComponent>, @Inject(MAT_DIALOG_DATA) public data: any){

  }

  handleFileInput(event: any) {
    let file = event.target.files;
    this.fileToUpload = file.item(0) as File;
    var reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }

  addProduct(){
    let product = {
      description: this.productForm.value.description!,
      price: this.productForm.value.price,
      productName: this.productForm.value.productName!,
      quantity: this.productForm.value.quantity,
      productimage : this.fileToUpload
    }
    this.pService.addProduct(product).subscribe(res => {
      if(res.hasOwnProperty('productId')){
        this.dialogRef.close("save");
      }
    });
  }

  close() {
    this.dialogRef.close("close");
  }
}
