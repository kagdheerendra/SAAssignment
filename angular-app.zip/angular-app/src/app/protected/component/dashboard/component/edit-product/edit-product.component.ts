import { Component, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ProtectedService } from '../../../../protected.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrl: './edit-product.component.scss'
})
export class EditProductComponent {

  productForm! : FormGroup;
  imageUrl: string = "/assets/img/noimage.png";
  private fileToUpload!: File;

  constructor(
    private pService: ProtectedService,
    private dialogRef: MatDialogRef<EditProductComponent>, @Inject(MAT_DIALOG_DATA) public data: any
  ){
    this.productForm = new FormGroup({
      productName: new FormControl(data.data.productName, [Validators.required,  Validators.maxLength(50)]),
      description: new FormControl(data.data.description, [Validators.required,  Validators.maxLength(250)]),
      quantity: new FormControl(data.data.quantity, [Validators.required, Validators.pattern("^-?[0-9][^\.]*$")]),
      price: new FormControl(data.data.price, [Validators.required]),
      productId : new FormControl(data.data.productId, [Validators.required]),
    })
    this.fileToUpload = data.data.productimage;
    this.imageUrl = "data:image/png;base64,"+this.fileToUpload;
  }

  handleFileInput(event: any) {
    let file = event.target.files;
    this.fileToUpload = file.item(0) as File;
    var reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }

  updateProduct(){
    let product = {
      description: this.productForm.value.description!,
      price: this.productForm.value.price,
      productName: this.productForm.value.productName!,
      quantity: this.productForm.value.quantity,
      productimage : this.fileToUpload,
      productid: this.data.data.productId
    }
    this.pService.udpateProduct(product).subscribe(res => {
      if(res.hasOwnProperty('productId')){
        this.dialogRef.close("save");
      }
    });
  }
}
