import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { GroupMemberDialogComponent } from './group-member-dialog/group-member-dialog.component';
import { ProtectedService } from '../../protected.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatTable } from '@angular/material/table';

@Component({
  selector: 'app-treeview',
  templateUrl: './treeview.component.html',
  styleUrl: './treeview.component.scss'
})
export class TreeviewComponent implements OnInit{

  displayedColumns: string[] = ['level', 'name'];
  tableDataSource: any[] = [];
  @ViewChild(MatTable) table!: MatTable<DepartmentTableElement>;

  TREE_DATA: DepartmentNode[] = [
    {
      id: 1,
      name: 'Infobeans',
      isDeleteEnable: true,
      children: [
      {
        name: 'HR',
        id: 2,
        isDeleteEnable: true,
        children: [
        {
          id: 3,
          name: 'abc',
          isDeleteEnable: true,
        }, 
        {
          id: 5,
          name: 'xyz',
          isDeleteEnable: true,
        }
        ],
      },
      {
        name: 'Tech',
        id: 4,
        isDeleteEnable: true,
        children: [
          {
            id: 6,
            isDeleteEnable: true,
            name: 'JavaDU'
          }
        ]
      }
      ]
    }
  ]

  currentUrl: string;
  allDepartment!: any;

  _flattenedData!:any;
  private _transformer = (node: DepartmentNode, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level,
      id: node.id,
      isDeleteEnable: node.isDeleteEnable
    };
  };
  
  treeControl = new FlatTreeControl<DepartmentFlatNode>(
    node => node.level,
    node => node.expandable
  );

  treeFlattener = new MatTreeFlattener(
    this._transformer,
    node => node.level,
    node => node.expandable,
    node => node.children,
  );

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);


  constructor(public dialog: MatDialog, public pservice : ProtectedService, private router: Router,
    private route: ActivatedRoute){
    this.currentUrl = this.router.url;
  }

  ngOnInit(): void {
    //this.dataSource.data = this.TREE_DATA;
    this.pservice.getAllDepartment().subscribe(res=>{
      this.allDepartment = res['body'][0];
      this.TREE_DATA = [this.allDepartment];
      this.setIsDeleteEnableProperty(this.TREE_DATA[0]);
      this.iterateAndSetDeleteProperty();
      this.dataSource.data = this.TREE_DATA;
      this.dataSource['_flattenedData']['_value'].forEach((value: any) => {
        let obj : DepartmentTableElement = {
          level : value.level,
          name : value.name
        };
        this.tableDataSource.push(obj);
        //this.table.renderRows();
      });
    })
  }

  hasChild = (_: number, node: DepartmentFlatNode) => node.expandable;
  
  openDialog(node : DepartmentNode) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.data = {
        'data' : {
          TREE_DATA : this.TREE_DATA,
          node : node
        }
      }
      const dialogRef = this.dialog.open(GroupMemberDialogComponent, dialogConfig);
      dialogRef.afterClosed().subscribe(
        data => {
          if(data && data != "close"){
            this.allDepartment = data;
            // this.allDepartment = {
            //   name: 'Infobeans',
            //   groupExist : true,
            //   children: [
            //     {
            //       name: 'HR',
            //       groupExist : true,
            //       children: [
            //         {name: 'abc', memberExist : true}, 
            //         {name: 'xyz', memberExist : true}
            //       ],
            //     },
            //     {
            //       name: 'Tech',
            //       groupExist : true,
            //       children: [{name: 'JavaDU', memberExist : true}]
            //     }
            //   ]
            // };
            this.pservice.saveDepartment(this.allDepartment).subscribe(res=>{
                this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
                  this.router.navigate([this.currentUrl]);
                });
            })
          }
        }
    );
  }

  deleteNode(node : DepartmentNode){
    this.pservice.deleteDepartment(node.id).subscribe(res=>{
        if(res){
          alert(res.body.message);
          this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
            this.router.navigate([this.currentUrl]);
          });
        }
    })
  }  

  iterateAndSetDeleteProperty(){
    this.TREE_DATA[0].isDeleteEnable = true;
    let objectsWithSingleChild = this.findObjectsWithSingleChild(this.TREE_DATA[0].children);
    for(let item of objectsWithSingleChild){
       this.findObjectById(this.TREE_DATA[0]['children'], item.id);
    }
  } 

  findObjectById(data : any, id : any) : any {
    // Check if the current data is an array
    if (Array.isArray(data)) {
        // Iterate through each element in the array
        for (const item of data) {
            // Check if the current item's ID matches the target ID
            if (item.id === id) {
                if(item.hasOwnProperty('children') && item.children.length == 1){
                  item.children[0].isDeleteEnable = false;
                }
                return item; // Return the item if found
            }
            // If the current item has children, recursively search within its children
            if (item.children && item.children.length > 0) {
                const foundInChildren = this.findObjectById(item.children, id);
                if (foundInChildren) {
                    foundInChildren.isDeleteEnable = false;
                    return foundInChildren; // Return the result from recursive call
                }
            }
        }
    }
    // If the object with the specified ID is not found, return null
    return null;
  };

  findObjectsWithSingleChild(data : any) : any{
      const result = [];
      // Iterate through each element in the current level of data
      for (const item of data) {
          // Check if the current item has exactly one child
          if (item.children && item.children.length === 1) {
              // Add the item to the result list
              result.push(item);
          }
          // If the current item has children, recursively search within its children
          if (item.children && item.children.length > 0) {
              const childrenResult = this.findObjectsWithSingleChild(item.children);
              // Concatenate the result from children recursion to the current result
              result.push(...childrenResult);
          }
      }
      return result;
  };

  setIsDeleteEnableProperty(treeData: any){
    treeData.children.forEach((item:any)=>{
        item.isDeleteEnable = true;
        if(item.hasOwnProperty('children') && item.children.length>0){
          this.setIsDeleteEnableProperty(item);
        }
    })
  }
}

interface DepartmentNode {
  name: string;
  id: number;
  isDeleteEnable: boolean;
  children?: DepartmentNode[];
}

interface DepartmentFlatNode {
  expandable: boolean;
  id:number;
  name: string;
  level: number;
  isDeleteEnable: boolean;
}

export interface DepartmentTableElement {
  name: string;
  level: number;
}
