import { ComponentFixture, TestBed } from '@angular/core/testing';

import { D3viewComponent } from './d3view.component';

describe('D3viewComponent', () => {
  let component: D3viewComponent;
  let fixture: ComponentFixture<D3viewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [D3viewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(D3viewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
