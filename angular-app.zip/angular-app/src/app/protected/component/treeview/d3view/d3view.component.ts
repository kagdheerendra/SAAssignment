  import {
    Component,
    AfterViewInit,
    Input,
    ElementRef,
    ViewChild,
    ViewChildren,
    QueryList,
    ViewEncapsulation,
    Renderer2,
    ComponentFactoryResolver,
    Injector,
    ViewContainerRef
  } from '@angular/core';
  import { fromEvent } from 'rxjs';
  import { map, startWith, tap } from 'rxjs/operators';
  import * as d3 from 'd3';
import { NodeContentComponent } from './node-content.component';
  
  @Component({
    selector: 'app-d3view',
    templateUrl: './d3view.component.html',
    styleUrl: './d3view.component.scss'
  })
  export class D3viewComponent implements AfterViewInit {

    treeData = {
      "name": "flare",
      "children": [
       {
        "name": "analytics",
        "children": [
         {
          "name": "cluster",
          "children": [
           {"name": "AgglomerativeCluster", "size": 3938},
           {"name": "CommunityStructure", "size": 3812},
           {"name": "HierarchicalCluster", "size": 6714},
           {"name": "MergeEdge", "size": 743}
          ]
         },
         {
          "name": "graph",
          "children": [
           {"name": "BetweennessCentrality", "size": 3534},
           {"name": "LinkDistance", "size": 5731},
           {"name": "MaxFlowMinCut", "size": 7840},
           {"name": "ShortestPaths", "size": 5914},
           {"name": "SpanningTree", "size": 3416}
          ]
         },
         {
          "name": "optimization",
          "children": [
           {"name": "AspectRatioBanker", "size": 7074}
          ]
         }
        ]
       },
       {
        "name": "animate",
        "children": [
         {"name": "Easing", "size": 17010},
         {"name": "FunctionSequence", "size": 5842},
         {
          "name": "interpolate",
          "children": [
           {"name": "ArrayInterpolator", "size": 1983},
           {"name": "ColorInterpolator", "size": 2047},
           {"name": "DateInterpolator", "size": 1375},
           {"name": "Interpolator", "size": 8746},
           {"name": "MatrixInterpolator", "size": 2202},
           {"name": "NumberInterpolator", "size": 1382},
           {"name": "ObjectInterpolator", "size": 1629},
           {"name": "PointInterpolator", "size": 1675},
           {"name": "RectangleInterpolator", "size": 2042}
          ]
         },
         {"name": "ISchedulable", "size": 1041},
         {"name": "Parallel", "size": 5176},
         {"name": "Pause", "size": 449},
         {"name": "Scheduler", "size": 5593},
         {"name": "Sequence", "size": 5534},
         {"name": "Transition", "size": 9201},
         {"name": "Transitioner", "size": 19975},
         {"name": "TransitionEvent", "size": 1116},
         {"name": "Tween", "size": 6006}
        ]
       },
       {
        "name": "data",
        "children": [
         {
          "name": "converters",
          "children": [
           {"name": "Converters", "size": 721},
           {"name": "DelimitedTextConverter", "size": 4294},
           {"name": "GraphMLConverter", "size": 9800},
           {"name": "IDataConverter", "size": 1314},
           {"name": "JSONConverter", "size": 2220}
          ]
         },
         {"name": "DataField", "size": 1759},
         {"name": "DataSchema", "size": 2165},
         {"name": "DataSet", "size": 586},
         {"name": "DataSource", "size": 3331},
         {"name": "DataTable", "size": 772},
         {"name": "DataUtil", "size": 3322}
        ]
       },
       {
        "name": "display",
        "children": [
         {"name": "DirtySprite", "size": 8833},
         {"name": "LineSprite", "size": 1732},
         {"name": "RectSprite", "size": 3623},
         {"name": "TextSprite", "size": 10066}
        ]
       },
       {
        "name": "flex",
        "children": [
         {"name": "FlareVis", "size": 4116}
        ]
       },
       {
        "name": "physics",
        "children": [
         {"name": "DragForce", "size": 1082},
         {"name": "GravityForce", "size": 1336},
         {"name": "IForce", "size": 319},
         {"name": "NBodyForce", "size": 10498},
         {"name": "Particle", "size": 2822},
         {"name": "Simulation", "size": 9983},
         {"name": "Spring", "size": 2213},
         {"name": "SpringForce", "size": 1681}
        ]
       },
       {
        "name": "query",
        "children": [
         {"name": "AggregateExpression", "size": 1616},
         {"name": "And", "size": 1027},
         {"name": "Arithmetic", "size": 3891},
         {"name": "Average", "size": 891},
         {"name": "BinaryExpression", "size": 2893},
         {"name": "Comparison", "size": 5103},
         {"name": "CompositeExpression", "size": 3677},
         {"name": "Count", "size": 781},
         {"name": "DateUtil", "size": 4141},
         {"name": "Distinct", "size": 933},
         {"name": "Expression", "size": 5130},
         {"name": "ExpressionIterator", "size": 3617},
         {"name": "Fn", "size": 3240},
         {"name": "If", "size": 2732},
         {"name": "IsA", "size": 2039},
         {"name": "Literal", "size": 1214},
         {"name": "Match", "size": 3748},
         {"name": "Maximum", "size": 843},
         {
          "name": "methods",
          "children": [
           {"name": "add", "size": 593},
           {"name": "and", "size": 330},
           {"name": "average", "size": 287},
           {"name": "count", "size": 277},
           {"name": "distinct", "size": 292},
           {"name": "div", "size": 595},
           {"name": "eq", "size": 594},
           {"name": "fn", "size": 460},
           {"name": "gt", "size": 603},
           {"name": "gte", "size": 625},
           {"name": "iff", "size": 748},
           {"name": "isa", "size": 461},
           {"name": "lt", "size": 597},
           {"name": "lte", "size": 619},
           {"name": "max", "size": 283},
           {"name": "min", "size": 283},
           {"name": "mod", "size": 591},
           {"name": "mul", "size": 603},
           {"name": "neq", "size": 599},
           {"name": "not", "size": 386},
           {"name": "or", "size": 323},
           {"name": "orderby", "size": 307},
           {"name": "range", "size": 772},
           {"name": "select", "size": 296},
           {"name": "stddev", "size": 363},
           {"name": "sub", "size": 600},
           {"name": "sum", "size": 280},
           {"name": "update", "size": 307},
           {"name": "variance", "size": 335},
           {"name": "where", "size": 299},
           {"name": "xor", "size": 354},
           {"name": "_", "size": 264}
          ]
         },
         {"name": "Minimum", "size": 843},
         {"name": "Not", "size": 1554},
         {"name": "Or", "size": 970},
         {"name": "Query", "size": 13896},
         {"name": "Range", "size": 1594},
         {"name": "StringUtil", "size": 4130},
         {"name": "Sum", "size": 791},
         {"name": "Variable", "size": 1124},
         {"name": "Variance", "size": 1876},
         {"name": "Xor", "size": 1101}
        ]
       },
       {
        "name": "scale",
        "children": [
         {"name": "IScaleMap", "size": 2105},
         {"name": "LinearScale", "size": 1316},
         {"name": "LogScale", "size": 3151},
         {"name": "OrdinalScale", "size": 3770},
         {"name": "QuantileScale", "size": 2435},
         {"name": "QuantitativeScale", "size": 4839},
         {"name": "RootScale", "size": 1756},
         {"name": "Scale", "size": 4268},
         {"name": "ScaleType", "size": 1821},
         {"name": "TimeScale", "size": 5833}
        ]
       },
       {
        "name": "util",
        "children": [
         {"name": "Arrays", "size": 8258},
         {"name": "Colors", "size": 10001},
         {"name": "Dates", "size": 8217},
         {"name": "Displays", "size": 12555},
         {"name": "Filter", "size": 2324},
         {"name": "Geometry", "size": 10993},
         {
          "name": "heap",
          "children": [
           {"name": "FibonacciHeap", "size": 9354},
           {"name": "HeapNode", "size": 1233}
          ]
         },
         {"name": "IEvaluable", "size": 335},
         {"name": "IPredicate", "size": 383},
         {"name": "IValueProxy", "size": 874},
         {
          "name": "math",
          "children": [
           {"name": "DenseMatrix", "size": 3165},
           {"name": "IMatrix", "size": 2815},
           {"name": "SparseMatrix", "size": 3366}
          ]
         },
         {"name": "Maths", "size": 17705},
         {"name": "Orientation", "size": 1486},
         {
          "name": "palette",
          "children": [
           {"name": "ColorPalette", "size": 6367},
           {"name": "Palette", "size": 1229},
           {"name": "ShapePalette", "size": 2059},
           {"name": "SizePalette", "size": 2291}
          ]
         },
         {"name": "Property", "size": 5559},
         {"name": "Shapes", "size": 19118},
         {"name": "Sort", "size": 6887},
         {"name": "Stats", "size": 6557},
         {"name": "Strings", "size": 22026}
        ]
       },
       {
        "name": "vis",
        "children": [
         {
          "name": "axis",
          "children": [
           {"name": "Axes", "size": 1302},
           {"name": "Axis", "size": 24593},
           {"name": "AxisGridLine", "size": 652},
           {"name": "AxisLabel", "size": 636},
           {"name": "CartesianAxes", "size": 6703}
          ]
         },
         {
          "name": "controls",
          "children": [
           {"name": "AnchorControl", "size": 2138},
           {"name": "ClickControl", "size": 3824},
           {"name": "Control", "size": 1353},
           {"name": "ControlList", "size": 4665},
           {"name": "DragControl", "size": 2649},
           {"name": "ExpandControl", "size": 2832},
           {"name": "HoverControl", "size": 4896},
           {"name": "IControl", "size": 763},
           {"name": "PanZoomControl", "size": 5222},
           {"name": "SelectionControl", "size": 7862},
           {"name": "TooltipControl", "size": 8435}
          ]
         },
         {
          "name": "data",
          "children": [
           {"name": "Data", "size": 20544},
           {"name": "DataList", "size": 19788},
           {"name": "DataSprite", "size": 10349},
           {"name": "EdgeSprite", "size": 3301},
           {"name": "NodeSprite", "size": 19382},
           {
            "name": "render",
            "children": [
             {"name": "ArrowType", "size": 698},
             {"name": "EdgeRenderer", "size": 5569},
             {"name": "IRenderer", "size": 353},
             {"name": "ShapeRenderer", "size": 2247}
            ]
           },
           {"name": "ScaleBinding", "size": 11275},
           {"name": "Tree", "size": 7147},
           {"name": "TreeBuilder", "size": 9930}
          ]
         },
         {
          "name": "events",
          "children": [
           {"name": "DataEvent", "size": 2313},
           {"name": "SelectionEvent", "size": 1880},
           {"name": "TooltipEvent", "size": 1701},
           {"name": "VisualizationEvent", "size": 1117}
          ]
         },
         {
          "name": "legend",
          "children": [
           {"name": "Legend", "size": 20859},
           {"name": "LegendItem", "size": 4614},
           {"name": "LegendRange", "size": 10530}
          ]
         },
         {
          "name": "operator",
          "children": [
           {
            "name": "distortion",
            "children": [
             {"name": "BifocalDistortion", "size": 4461},
             {"name": "Distortion", "size": 6314},
             {"name": "FisheyeDistortion", "size": 3444}
            ]
           },
           {
            "name": "encoder",
            "children": [
             {"name": "ColorEncoder", "size": 3179},
             {"name": "Encoder", "size": 4060},
             {"name": "PropertyEncoder", "size": 4138},
             {"name": "ShapeEncoder", "size": 1690},
             {"name": "SizeEncoder", "size": 1830}
            ]
           },
           {
            "name": "filter",
            "children": [
             {"name": "FisheyeTreeFilter", "size": 5219},
             {"name": "GraphDistanceFilter", "size": 3165},
             {"name": "VisibilityFilter", "size": 3509}
            ]
           },
           {"name": "IOperator", "size": 1286},
           {
            "name": "label",
            "children": [
             {"name": "Labeler", "size": 9956},
             {"name": "RadialLabeler", "size": 3899},
             {"name": "StackedAreaLabeler", "size": 3202}
            ]
           },
           {
            "name": "layout",
            "children": [
             {"name": "AxisLayout", "size": 6725},
             {"name": "BundledEdgeRouter", "size": 3727},
             {"name": "CircleLayout", "size": 9317},
             {"name": "CirclePackingLayout", "size": 12003},
             {"name": "DendrogramLayout", "size": 4853},
             {"name": "ForceDirectedLayout", "size": 8411},
             {"name": "IcicleTreeLayout", "size": 4864},
             {"name": "IndentedTreeLayout", "size": 3174},
             {"name": "Layout", "size": 7881},
             {"name": "NodeLinkTreeLayout", "size": 12870},
             {"name": "PieLayout", "size": 2728},
             {"name": "RadialTreeLayout", "size": 12348},
             {"name": "RandomLayout", "size": 870},
             {"name": "StackedAreaLayout", "size": 9121},
             {"name": "TreeMapLayout", "size": 9191}
            ]
           },
           {"name": "Operator", "size": 2490},
           {"name": "OperatorList", "size": 5248},
           {"name": "OperatorSequence", "size": 4190},
           {"name": "OperatorSwitch", "size": 2581},
           {"name": "SortOperator", "size": 2023}
          ]
         },
         {"name": "Visualization", "size": 16540}
        ]
       }
      ]
     };

    @Input() duration = 750;

    @ViewChild('marginDiv') marginDiv!: ElementRef;
    @ViewChild('wrapper') wrapper!: ElementRef;
    margin = { top: 0, right: 30, bottom: 0, left: 30 };
    width!: number;
    height!: number;
    svg: any;
    root: any;
  
    //  duration = d3.event && d3.event.altKey ? 500 : 500;
    i = 0;
    treemap: any;
    fontSize = fromEvent(window, 'resize').pipe(
      startWith(null),
      map((_) => {
        let size=this.wrapper?this.wrapper.nativeElement.getBoundingClientRect().width:window.innerWidth
        return size?(14 * 960) / size + 'px':'14px'
      }),
      tap((_) => {
        setTimeout(() => {
          const inc = this.marginDiv.nativeElement.getBoundingClientRect().width;
          this.svg.attr(
            'transform',
            'translate(' + (this.margin.left + inc) + ',' + this.margin.top + ')'
          );
        });
      })
    );
  
    private renderer: Renderer2;
    constructor(private elementRef: ElementRef, private rendr: Renderer2, private resolver: ComponentFactoryResolver, private injector: Injector, private viewContainerRef: ViewContainerRef) { 
       this.renderer = rendr;
    }

    ngAfterViewInit(): void {
      //this.createTree();
      const inc = this.marginDiv.nativeElement.getBoundingClientRect().width;
      (this.width = 960 - inc - this.margin.left - this.margin.right),
        (this.height = 500 - this.margin.top - this.margin.bottom);
  
      this.svg = d3.select(this.elementRef.nativeElement).append('svg')
        .attr('viewBox', '0 0 960 500')
        .append('g')
        .attr(
          'transform',
          'translate(' + (this.margin.left + inc) + ',' + this.margin.top + ')'
        );

      // declares a tree layout and assigns the size
      this.treemap = d3.tree<TreeNode>().size([this.height, this.width]);
  
      // Assigns parent, children, height, depth
      this.root = d3.hierarchy<TreeNode>(this.treeData, (d: any) => {
        return d.children;
      });
  
      this.root.x0 = this.height / 2;
      this.root.y0 = 0;
      // Collapse after the second level
      this.root.children.forEach((d: any) => {
        this.collapse(d);
      });
      this.update(this.root);
    }

    update(source: any) {
      // Assigns the x and y position for the nodes
      const treeData = this.treemap(this.root);
  
      // Compute the new tree layout.
      const nodes = treeData.descendants();
      const links = treeData.descendants().slice(1);
  
      // Normalize for fixed-depth.
      nodes.forEach((d: any) => {
        d.y = d.depth * 180;
      });
  
      // ****************** Nodes section ***************************
  
      // Update the nodes...
      const node = this.svg.selectAll('g.node').data(nodes, (d: any) => {
        return d.id || (d.id = ++this.i);
      });
  
      // Enter any new modes at the parent's previous position.
      const nodeEnter = node
        .enter()
        .append('g')
        .attr('class', 'node')
        .attr('transform', (d: any) => {
          return 'translate(' + source.y0 + ',' + source.x0 + ')';
        })
        .on('click', (_: any, d: any) => this.click(d));
  
      // Add Circle for the nodes
      nodeEnter
        .append('circle')
        .attr('class', (d: any) => (d._children ? 'node fill' : 'node'))
        .attr('r', 1e-6);
      // Add labels for the nodes

      // Dynamically render Angular component inside each node
      nodeEnter.each((d: { data: any; }, i: string | number, nodes: { [x: string]: any; }) => {
        const nodeElement = nodes[i];

        const componentFactory = this.resolver.resolveComponentFactory(NodeContentComponent);
        const componentRef = this.viewContainerRef.createComponent(componentFactory);
        
        // Pass data to the component
        componentRef.instance.nodeData = d.data;
        
        // Append the component to the node
        const componentElement = componentRef.location.nativeElement;
        nodeElement.appendChild(componentElement);
      });


      // Append rectangles for each node
      // const rect = nodeEnter.append('rect')
      //   .attr('width', 100)
      //   .attr('height', 30)
      //   .attr('x', -40)
      //   .attr('y', -15)
      //   .attr('rx', 5)
      //   .attr('ry', 5)
      //   .style('fill', 'lightblue')
      //   .style('cursor', 'pointer')
        //.on('click', (event: any, d: any) => this.openMenu(event));


    // //Add SVG icons for add and delete buttons within each node
    // nodeEnter.append('svg:image')
    //   .attr('xlink:href', 'assets/img/plus.svg') // Path to Bootstrap add icon
    //   .attr('width', 20)
    //   .attr('height', 20)
    //   .attr('x', -10) // Position the icon to the left of the node
    //   .attr('y', 15) // Adjust vertical position if needed
    //   .attr('cursor', 'pointer')
    //   .on('click', (event: any, d: any) => {
    //     event.stopPropagation();
    //     console.log(d);
    //     //this.handleAddButtonClick(d); // Handle add button click event
    //   });

    // nodeEnter.append('svg:image')
    //   .attr('xlink:href', 'assets/img/trash.svg') // Path to Bootstrap delete icon
    //   .attr('width', 20)
    //   .attr('height', 20)
    //   .attr('x', -10) // Position the icon to the right of the node
    //   .attr('y', -35) // Adjust vertical position if needed
    //   .attr('cursor', 'pointer')
    //   .on('click', (event: any, d: any) => {
    //     event.stopPropagation();
    //     console.log(d);
    //     //this.handleDeleteButtonClick(d); // Handle delete button click event
    //   });  

      nodeEnter
        .append('text')
        .attr('text-rendering','optimizeLegibility')
        .attr('dy', '.35em')
        .style('fill', 'white')
        //.attr('y','-25')
        .attr('x', (d: { children: any; _children: any; }) => {
          return d.children || d._children ? -13 : 13;
        })
        .attr('text-anchor', (d: any) => {
          return d.children || d._children ? 'end' : 'start';
        })
        .text((d: { data: { name: any; }; }) => {
          return d.data.name;
        });
      // UPDATE
      const nodeUpdate = nodeEnter.merge(node);
  
      // Transition to the proper position for the node
      nodeUpdate
        .transition()
        .duration(this.duration)
        .attr('transform', (d: any) => {
          return 'translate(' + d.y + ',' + d.x + ')';
        });
  
      // Update the node attributes and style
      nodeUpdate
        .select('circle.node')
        .attr('r', 10)
        .attr('class', (d: any) => (d._children ? 'node fill' : 'node'))
        .attr('cursor', 'pointer');
  
      // Remove any exiting nodes
      const nodeExit = node
        .exit()
        .transition()
        .duration(this.duration)
        .attr('transform', (d: any) => {
          return 'translate(' + source.y + ',' + source.x + ')';
        })
        .remove();
  
      // On exit reduce the node circles size to 0
      nodeExit.select('circle').attr('r', 1e-6);
  
      // On exit reduce the opacity of text labels
      nodeExit.select('text').style('fill-opacity', 1e-6);
  
      // ****************** links section ***************************
  
      // Update the links...
      const link = this.svg.selectAll('path.link').data(links, (d: any) => {
        return d.id;
      });
  
      // Enter any new links at the parent's previous position.
      const linkEnter = link
        .enter()
        .insert('path', 'g')
        .attr('class', 'link')
        .attr('d', (d: any) => {
          const o = { x: source.x0, y: source.y0 };
          return this.diagonal(o, o);
        });
  
      // UPDATE
      const linkUpdate = linkEnter.merge(link);
  
      // Transition back to the parent element position
      linkUpdate
        .transition()
        .duration(this.duration)
        .attr('d', (d: any) => {
          return this.diagonal(d, d.parent);
        });
  
      // Remove any exiting links
      const linkExit = link
        .exit()
        .transition()
        .duration(this.duration)
        .attr('d', (d: any) => {
          const o = { x: source.x, y: source.y };
          return this.diagonal(o, o);
        })
        .remove();
  
      // Store the old positions for transition.
      nodes.forEach((d: any) => {
        d.x0 = d.x;
        d.y0 = d.y;
      });


          // Append foreignObject with context menu to each node
      nodeEnter.append('foreignObject')
      .attr('width', 30)
      .attr('height', 30) 
      .attr('x', '-50')
      .attr('y','10')
      .on('contextmenu', (event: any, d: any) => this.showContextMenu(event, d))
      .html((d: { data: { name: any; }; }) => `<button type="button" class="btn btn-link">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
      <path d="M8 4.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"/>
      </svg>
      </button>`);
    }

    showContextMenu(event: MouseEvent, d: any): void {
      event.preventDefault(); // Prevent default browser context menu
  
      // Define context menu items
      const contextMenu = `
        <div class="context-menu">
          <button type="button" class="btn btn-light"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
        </svg></button>
          <button type="button" class="btn btn-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
          <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
          <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
        </svg></button>
        </div>
      `;
  
      // Append context menu to the tree container
      const treeContainer = this.elementRef.nativeElement as HTMLElement;
      treeContainer.insertAdjacentHTML('beforeend', contextMenu);
  
      // Position the context menu
      const contextMenuEl = treeContainer.querySelector('.context-menu') as HTMLElement;
      contextMenuEl.style.position = 'absolute';
      contextMenuEl.style.left = `${event.pageX}px`;
      contextMenuEl.style.top = `${event.pageY}px`;
  
      // Handle context menu item actions (e.g., click events)
      contextMenuEl.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', () => {
          console.log(`Clicked ${btn.textContent} for node: ${d.data.name}`);
          // Implement action based on the clicked menu item
          contextMenuEl.remove(); // Remove context menu after action
        });
      });
  
      // Close context menu on outside click
      document.addEventListener('click', (e) => {
        if (!contextMenuEl.contains(e.target as Node)) {
          contextMenuEl.remove(); // Remove context menu if clicked outside
        }
      });
    }    

    openMenu(event: MouseEvent): void {
      console.log('menu button clicked');
      const menu = d3.select((event.currentTarget as HTMLElement).nextElementSibling);
      const isVisible = menu.style('display') === 'block';
      menu.style('display', isVisible ? 'none' : 'block');
      event.stopPropagation(); // Prevent click event from propagating
    }
  
    handleAddButtonClick(event: MouseEvent): void {
      console.log('Add button clicked');
      event.stopPropagation(); // Prevent propagation to avoid collapsing
      // Implement add button logic here
    }
  
    handleDeleteButtonClick(event: MouseEvent): void {
      console.log('Delete button clicked');
      event.stopPropagation(); // Prevent propagation to avoid collapsing
      // Implement delete button logic here
    }
    
    collapse(d: any) {
      if (d.children) {
        d._children = d.children;
        d._children.forEach((d: any) => this.collapse(d));
        d.children = null;
      }
    }
  
    click(d: any) {
      if (d.children) {
        d._children = d.children;
        d.children = null;
      } else {
        d.children = d._children;
        d._children = null;
      }
      this.update(d);
    }
  
    diagonal(s: any, d: any) {
      const path = `M ${s.y} ${s.x}
              C ${(s.y + d.y) / 2} ${s.x},
                ${(s.y + d.y) / 2} ${d.x},
                ${d.y} ${d.x}`;
  
      return path;
    }  

  }

  interface TreeNode {
    name: string;
    children?: TreeNode[];
  }
  