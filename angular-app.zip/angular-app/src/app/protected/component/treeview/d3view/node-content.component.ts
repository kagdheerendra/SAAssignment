import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-node-content',
  template: `
          <div style="display: flex; align-items: center; justify-content: space-between; height: 100%; width: 100%;">
            <button class="btn btn-link" (click)="openMenu($event)">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                <path d="M8 4.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"/>
              </svg>
            </button>
            <div class="menu" style="display: none;">
              <button class="btn btn-link" (click)="handleAddButtonClick($event)">Add</button>
              <button class="btn btn-link" (click)="handleDeleteButtonClick($event)">Delete</button>
            </div>
          </div>	
  `,
  styles: `
    .node-content {
      display: flex;
      align-items: center;
    }
    svg {
      width: 24px;
      height: 24px;
      margin-right: 8px;
    }
    button {
      margin-left: 8px;
    }
  `
})
export class NodeContentComponent {
  @Input() nodeName!: string;
  nodeData: any;

  openMenu(event: any): void {
    console.log('Menu opened for node:', this.nodeName);
    // Implement menu logic here
    event.stopPropagation();
  }

    
  handleAddButtonClick(event: MouseEvent): void {
    console.log('Add button clicked');
    event.stopPropagation(); // Prevent propagation to avoid collapsing
    // Implement add button logic here
  }

  handleDeleteButtonClick(event: MouseEvent): void {
    console.log('Delete button clicked');
    event.stopPropagation(); // Prevent propagation to avoid collapsing
    // Implement delete button logic here
  }
}
