import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupMemberDialogComponent } from './group-member-dialog.component';

describe('GroupMemberDialogComponent', () => {
  let component: GroupMemberDialogComponent;
  let fixture: ComponentFixture<GroupMemberDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GroupMemberDialogComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GroupMemberDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
