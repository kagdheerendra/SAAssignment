import { Component, Inject, OnInit } from '@angular/core';
import { ProtectedService } from '../../../protected.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as XLSX from 'xlsx'; 

@Component({
  selector: 'app-group-member-dialog',
  templateUrl: './group-member-dialog.component.html',
  styleUrl: './group-member-dialog.component.scss'
})
export class GroupMemberDialogComponent implements OnInit{

  node : any;
  TREE_DATA! : any[];
  //srcResult: any;
  groupObj!:any;
  memberObj!:any;
  finalNode: any;
  isGroupAlreadyExist : boolean = false;
  isMemberExist : boolean = false;
  selectedNodeFromTreeData : any;
  groupForm = new FormGroup({
    groupName: new FormControl("", [Validators.required,  Validators.maxLength(50)])
  })

  constructor(private pService: ProtectedService,private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<GroupMemberDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any){
      this.node = this.data.data['node'];
      this.TREE_DATA = this.data.data['TREE_DATA'];
  }

  ngOnInit(): void {

  }

  close() {
    this.dialogRef.close("close");
  }


  onFileSelected(mode : string) {
    const file: any = document.querySelector('#file');
    if (typeof (FileReader) !== 'undefined') {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        //this.srcResult = e.target.result;
        let data = (<any>e.target).result;
        let workbook = XLSX.read(data, {
          type: 'binary'
        });
        workbook.SheetNames.forEach(( (sheetName: any) => {
          // Here is your object  
          let XL_row_object = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
          let json_object = JSON.stringify(XL_row_object);
          // bind the parse excel file data to Grid  
          if(mode == "fromGroup"){
            this.groupObj = JSON.parse(json_object);
            this.groupObj.forEach((element:any) => {
              element.memberExist = true
            });
          }else{
            this.memberObj = JSON.parse(json_object);
            this.memberObj.forEach((element:any) =>  {
              element.memberExist = true
            });
          }
        }).bind(this), this);
      };
      reader.readAsArrayBuffer(file.files[0]);
    }
  }
  
  save(){
    if(this.groupForm.invalid && this.groupObj == undefined && this.memberObj == undefined){
      alert("Please add group or member");
      return;
    }
    if(this.groupObj !== undefined && this.groupObj.length > 0) {
      this.checkIfGroupAlreadyExists(this.TREE_DATA[0], this.groupForm.value.groupName);
      this.addGroup(this.node, this.TREE_DATA);
    }
    if(this.memberObj !== undefined && this.memberObj.length > 0) {
      this.findSelectedNodeFromTreeData(this.node, this.TREE_DATA[0]);
      this.memberObj.forEach((member:any) => {
        this.checkIfMemberAlreadyExists(this.selectedNodeFromTreeData, member);
      });
      this.addMember(this.node, this.TREE_DATA);
    }
    //this.dialogRef.close(this.TREE_DATA);
    this.dialogRef.close(this.finalNode);

  }

  addGroup(node: any, treeNode:any){
    if(!this.isGroupAlreadyExist){
      for(let e of treeNode){
        if(e['name'] === node['name']){
          this.finalNode = e;
          this.finalNode['children'].push(
            {
              name: this.groupForm.value.groupName, 
              groupExist : true,
              children: this.groupObj
            }
          );
          break;
        }else if(e.hasOwnProperty('children')){
          this.addGroup(node, e['children']);
        }
      }
    }
  }

  addMember(node: any, treeNode:any){
    if(!this.isMemberExist){
      for(let t of treeNode){
        if(t['name'] == node['name']){
          this.finalNode = t;
          this.memberObj.forEach((name : any) => {
            this.finalNode['children'].push(name);
          });
          break;
        }else if(t.hasOwnProperty('children')){
          this.addMember(node, t['children']);
        }
      }
    }
  }

  checkIfGroupAlreadyExists(node : any, g: any){
    if(node.hasOwnProperty('children') && node.children.length > 0){
      if(g === node.name) {
        alert("Group Already Exist!");
        this.isGroupAlreadyExist = true;
        return;
      }else if(node.hasOwnProperty('children') && node.children.length > 0){
        node.children.forEach((node:any) => {
           this.checkIfGroupAlreadyExists(node, g);
        });
      }   
    }
  }

  checkIfMemberAlreadyExists(node : any, member: any){
    if(node.hasOwnProperty('children') && node.children.length>0){
      for(let item of node.children){
        if(member.name === item.name){
          alert(member.name+" Member Already Exist");
          this.isMemberExist = true;
          return;
        }
      }
    }
  }

  findSelectedNodeFromTreeData(node: any, treeData: any){
    if(node.name === treeData.name){
      this.selectedNodeFromTreeData = treeData;
      return;
    }else if(treeData.hasOwnProperty('children') && treeData.children.length>0){
      treeData.children.forEach((e:any) => {
        this.findSelectedNodeFromTreeData(node, e);
      });
    }
  }
}
